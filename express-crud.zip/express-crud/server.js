const express = require('express');
const app = express();
const db = require('./app/models/index.js');
const routes = require('./app/routes/routes');
const bodyParser = require('body-parser');
const cluster = require('cluster');
const numCPU = require('os').cpus().length;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(routes); 
app.use(express.json());


if(cluster.isMaster){
  for (let index = 0; index < numCPU; index++) {
      cluster.fork();
  }
  cluster.on('exit',() => {
      cluster.fork();
  })
}else{
  db.mongoose.connect(db.url).then(() => {
    console.log("Connected to the database!");  
  }).catch(err => { 
    console.log("Cannot connect to the database!", err);
    process.exit();
  });
  const PORT =  8888;
app.listen(PORT, () => {
  console.log(`Listening on PORT ${PORT} and PID is ${process.pid}`);
})
}



