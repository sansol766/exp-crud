const express = require('express');
let app = express.Router();
const bookRoutes = require('../controller/book.controller.js')
app.get("/getbookdetails", bookRoutes.getBookDetails);
app.post("/savebookdetails", bookRoutes.saveBookDetails);
app.put("/updatebookdetails", bookRoutes.updateBookDetails);
app.delete("/deletebookdetails", bookRoutes.deleteBookDetails);

module.exports = app;