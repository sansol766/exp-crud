const express = require('express');
var app = express.Router();
const bookRoute = require('./book.route.js');

app.use('/',bookRoute)
module.exports = app

