const mongoose = require('mongoose');
const AutoIncrement = require('mongoose-sequence')(mongoose);
const bookdetailSchema = mongoose.Schema(
    {
        title : String,
        author : String,
        bookId : Number,
        summary : String
    }, {
        timestamps: true,
    }
);
bookdetailSchema.plugin(AutoIncrement, {
   id : 'bookdetailSchema_seq',
   inc_field : 'bookId',
});
module.exports = mongoose.model('dummy_table', bookdetailSchema); 

