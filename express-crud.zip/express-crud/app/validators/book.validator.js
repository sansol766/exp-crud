const Joi = require("joi");
const validator = schema => payloads => schema.validate(payloads);


const validateBookEntry = Joi.object().keys({
   title : Joi.string().required(),
   author : Joi.string().required(),
   summary : Joi.string().required()
});

const validateBookParams = Joi.object().keys({
   id : Joi.number().optional()
});

const validateUpdateBookParams = Joi.object().keys({
   id : Joi.number().required(),
   title : Joi.string().required(),
   author : Joi.string().required(),
   summary : Joi.string().required()
});

const validateBookId = Joi.object().keys({
   id : Joi.number().required()
});

exports.validateBookEntry = validator(validateBookEntry);
exports.validateBookParams = validator(validateBookParams);
exports.validateUpdateBookParams = validator(validateUpdateBookParams);
exports.validateBookId = validator(validateBookId);