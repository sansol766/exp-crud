const { on } = require('nodemon');
const book_table = require('../models/book.model.js');
const { validateBookEntry , validateBookParams , validateUpdateBookParams , validateBookId } = require('../validators/book.validator.js');
const fileName = __filename.split(/[\\/]/).pop();


exports.getBookDetails = async ( req , res ) => {
   const { error } = validateBookParams ( req.query );
   if( error ) {
      res.status(401).json({
        "status" : false, 
        "message" : "Invalid request",
        "error" : error.message
      })
      }else{
        try {
         let { id } =  req.query  , reqObj = {} , oneRes , mulRes ,totCount;
         id = Number(id)
         if(id){
            reqObj.bookId = id ;
            oneRes = await  book_table.findOne(reqObj);
            if(oneRes){
               res.status(200).json({
               "status" : true,
               "count" : 1,
               "data" : oneRes
            })  
            }else{
               res.status(200).json({
                  "status" : false,
                  "data" : [],
                  "count" : 0,
                  "message" : "Result Not found"
              })  
            }
         }else{
            totCount = await book_table.countDocuments();
             mulRes =  await book_table.find(reqObj, {
               "_id": false,
               "createdAt" : false,
               "updatedAt" : false,
               "__v" : false
             }).skip(0).limit(50);
               if(mulRes){
                  res.status(200).json({
                  "status" : true,
                  "count" : totCount,
                  "data" : mulRes
               })  
            }
         }         
        } catch (error) {
        res.status(500).json({ 
            status : false, 
            message : err.message
          });   
        }
      }
    }


exports.saveBookDetails = async ( req , res ) => {
   const { error } =  validateBookEntry(req.body);  
   if (error) {
                return res.status(400).json({  
                  "status": false, 
                  "message": "Invalid Request", 
                  "data": error.message
               });      
   }else{
      try {
        const { title , author , summary } = req.body ;
         let query = {
            "title" : title,
            "author" : author,
            "summary" : summary
         }
        let dupRec =  await book_table.find(query);
        if (dupRec.length > 0) {
         res.status(409).json({  
            "status": true, 
            "message": "Book Already Exists"
         })
        } else {
         let book_entry = {
            "title" :  title,
            "author" :  author,
            "summary" :  summary
        }
        const savePayload = new book_table(book_entry);
        let result = await savePayload.save();
        if(result){
         res.status(201).json({
            "status": true, 
            "message": "Book Added Successfully",
         })
      }else{
         res.status(500).json({  
            "status": false, 
            "message": "Book Not Added"
         })
      }
        }
     }
     catch (error) { 
      res.status(500).json({ 
         status : false, 
         message : error.message
       });   
     }
   }
   
}

exports.updateBookDetails = async function (req, res) {
try {
      const { error } = validateUpdateBookParams( req.body );
      if (error) {
       return res.status(400).json({  
          "status": false, 
          "message": "Invalid Request", 
          "data": error.message
       });   
      }else{
         const { id , title , author, summary } = req.body;
         //  id = Number(id)
         let payload ;
         payload = {  id , title , author , summary}
           
            let recordUpdate = await book_table.findOneAndUpdate(
               { bookId : id },payload,
               {
                  new: true,
              }
            )
            if(recordUpdate) {
               res.status(200).json({
                  "status" : true,
                  "message" : "Data Updated Successfully",
                  "data" : payload
                  })
            }else{
               res.status(200).json({
                  "status" : false,
                  "message" : "Data Not Updated ",
                  "data" : []
                  })
            }
          
       
      }
   } catch (error) {
      res.status(500).json({ 
         status : false, 
         message : error.message
       });   
   }
}

exports.deleteBookDetails = async (req, res) => {
   try {
      const { error } = validateBookId( req.query );
      if (error) {
       return res.status(400).json({  
          "status": false, 
          "message": "Invalid Request", 
          "data": error.message
       });   
      }else{
         let {id} = req.query;
             id = Number(id)
         let deleteOneRec = await book_table.deleteOne({"bookId" : id})
             if (deleteOneRec.deletedCount !== 1) {
               res.status(404).send({
               status : false, 
                 message: `Cannot delete Book with id=${id}. Maybe Book was not found!`
               });
             } else {
               res.send({
                  status : true, 
                 message: "Book was deleted successfully!"
               });
             }
      }
   } catch (error) {
      res.status(500).json({ 
         status : false, 
         message : error.message
       }); 
   }
 };